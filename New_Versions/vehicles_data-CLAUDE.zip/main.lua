-- Vehicle Data Scanner - Server Side (Optimized)
-- Manages command, progress tracking, and file export
-- Integrated with ox_lib for modern notifications

local scanInProgress = false
local scanResults = {}
local scanStartTime = 0
local activeScanPlayer = nil

-- Modern notification system using ox_lib
local function notifyPlayer(playerId, message, type)
    TriggerClientEvent('ox_lib:notify', playerId, {
        title = 'Vehicle Scanner',
        description = message,
        type = type or 'info',
        position = Config.NotifyPosition,
        duration = Config.NotifyDuration
    })
end

-- Notify all players
local function notifyAll(message, type)
    local allPlayers = ESX.GetPlayers()
    for _, playerId in ipairs(allPlayers) do
        notifyPlayer(playerId, message, type)
    end
    print('^2[Vehicle Scanner]^7 ' .. message)
end

-- Notify only the player who initiated the scan
local function notifyScanInitiator(message, type)
    if activeScanPlayer then
        notifyPlayer(activeScanPlayer, message, type)
    end
    print('^2[Vehicle Scanner]^7 ' .. message)
end

-- Format time duration
local function formatDuration(seconds)
    if seconds < 60 then
        return string.format('%.1fs', seconds)
    elseif seconds < 3600 then
        local minutes = math.floor(seconds / 60)
        local secs = seconds % 60
        return string.format('%dm %ds', minutes, secs)
    else
        local hours = math.floor(seconds / 3600)
        local minutes = math.floor((seconds % 3600) / 60)
        return string.format('%dh %dm', hours, minutes)
    end
end

-- Calculate estimated time remaining
local function calculateETA(current, total, elapsedTime)
    if current == 0 then return 'Calculating...' end
    
    local avgTimePerVehicle = elapsedTime / current
    local remaining = total - current
    local etaSeconds = avgTimePerVehicle * remaining
    
    return formatDuration(etaSeconds)
end

-- Server event: Receive progress updates from client
RegisterNetEvent('vehiclescanner:updateProgress', function(vehicleName, current, total, status)
    local elapsedTime = os.time() - scanStartTime
    local eta = calculateETA(current, total, elapsedTime)
    local progressPercent = math.floor((current / total) * 100)
    
    if status == 'success' then
        local message = string.format('✓ %s [%d/%d - %d%%] ETA: %s', 
            vehicleName, current, total, progressPercent, eta)
        notifyScanInitiator(message, 'success')
    else
        local message = string.format('✗ ERROR: %s [%d/%d - %d%%]', 
            vehicleName, current, total, progressPercent)
        notifyScanInitiator(message, 'error')
    end
    
    if Config.DebugMode then
        print(string.format('^3[DEBUG] Progress: %s (%d/%d) - %s | Elapsed: %s | ETA: %s^7', 
            vehicleName, current, total, status, formatDuration(elapsedTime), eta))
    end
end)

-- Server event: Receive final scan results
RegisterNetEvent('vehiclescanner:scanComplete', function(results)
    scanResults = results
    local totalTime = os.time() - scanStartTime
    scanInProgress = false

    -- Write to file
    local jsonData = json.encode(results, {indent = true})
    local resourceName = GetCurrentResourceName()
    
    SaveResourceFile(resourceName, Config.OutputFile, jsonData, -1)

    -- Prepare summary
    local successCount = 0
    local errorCount = 0
    local totalVehicles = 0

    for _, data in pairs(results) do
        totalVehicles = totalVehicles + 1
        if data.error then
            errorCount = errorCount + 1
        else
            successCount = successCount + 1
        end
    end

    -- Calculate performance metrics
    local avgTimePerVehicle = totalTime / totalVehicles
    local vehiclesPerMinute = (totalVehicles / totalTime) * 60

    -- Send completion notification
    local summaryMessage = string.format(
        'Scan completed!\n✓ Success: %d | ✗ Errors: %d\nTotal time: %s (%.1f vehicles/min)\nFile: %s',
        successCount, errorCount, formatDuration(totalTime), vehiclesPerMinute, Config.OutputFile
    )
    
    notifyScanInitiator(summaryMessage, 'success')

    if Config.DebugMode then
        local path = 'resources/' .. resourceName .. '/' .. Config.OutputFile
        print('^2[Vehicle Scanner] Data saved to:^7 ' .. path)
        print(string.format('^2[Vehicle Scanner] Performance: %.2fs avg per vehicle^7', avgTimePerVehicle))
    end
    
    -- Reset active scan player
    activeScanPlayer = nil
end)

-- Server event: Receive notifications from client
RegisterNetEvent('vehiclescanner:notify', function(message)
    local source = source
    notifyPlayer(source, message, 'warning')
end)

-- Command to start vehicle data scan
ESX.RegisterCommand('getvehicledata', 'user', function(xPlayer, args, showError)
    if scanInProgress then
        notifyPlayer(xPlayer.source, 'Scan already in progress!', 'error')
        return
    end

    if #Config.Vehicles == 0 then
        notifyPlayer(xPlayer.source, 'No vehicles configured in config.lua', 'error')
        return
    end

    scanInProgress = true
    scanStartTime = os.time()
    activeScanPlayer = xPlayer.source
    
    local totalVehicles = #Config.Vehicles
    local estimatedTime = (totalVehicles / Config.BatchSize) * (Config.BatchDelay / 1000)
    
    local startMessage = string.format(
        'Starting scan of %d vehicles\nBatch size: %d | Est. time: %s',
        totalVehicles, Config.BatchSize, formatDuration(estimatedTime)
    )
    
    notifyPlayer(xPlayer.source, startMessage, 'info')
    
    -- Request client to start scanning
    TriggerClientEvent('vehiclescanner:startScan', xPlayer.source, Config.Vehicles)
    
    if Config.DebugMode then
        print(string.format('^2[Vehicle Scanner] Scan initiated by %s (ID: %d)^7', 
            xPlayer.getName(), xPlayer.source))
    end
end, true, {
    help = 'Scan all configured vehicles and export data to JSON file',
    args = {}
})

-- Alternative command variant
ESX.RegisterCommand('scanvehicles', 'user', function(xPlayer, args, showError)
    if scanInProgress then
        notifyPlayer(xPlayer.source, 'Scan already in progress!', 'error')
        return
    end

    if #Config.Vehicles == 0 then
        notifyPlayer(xPlayer.source, 'No vehicles configured in config.lua', 'error')
        return
    end

    scanInProgress = true
    scanStartTime = os.time()
    activeScanPlayer = xPlayer.source
    
    local totalVehicles = #Config.Vehicles
    local estimatedTime = (totalVehicles / Config.BatchSize) * (Config.BatchDelay / 1000)
    
    local startMessage = string.format(
        'Starting scan of %d vehicles\nBatch size: %d | Est. time: %s',
        totalVehicles, Config.BatchSize, formatDuration(estimatedTime)
    )
    
    notifyPlayer(xPlayer.source, startMessage, 'info')
    
    TriggerClientEvent('vehiclescanner:startScan', xPlayer.source, Config.Vehicles)
    
    if Config.DebugMode then
        print(string.format('^2[Vehicle Scanner] Scan initiated by %s (ID: %d)^7', 
            xPlayer.getName(), xPlayer.source))
    end
end, true, {
    help = 'Scan all configured vehicles and export data to JSON file',
    args = {}
})

-- Command to cancel scan
ESX.RegisterCommand('cancelscan', 'user', function(xPlayer, args, showError)
    if not scanInProgress then
        notifyPlayer(xPlayer.source, 'No scan in progress!', 'error')
        return
    end

    if activeScanPlayer and activeScanPlayer ~= xPlayer.source then
        notifyPlayer(xPlayer.source, 'You cannot cancel a scan started by another player', 'error')
        return
    end

    scanInProgress = false
    activeScanPlayer = nil
    
    TriggerClientEvent('vehiclescanner:cancelScan', xPlayer.source)
    notifyPlayer(xPlayer.source, 'Vehicle scan cancelled', 'warning')
    
    if Config.DebugMode then
        print(string.format('^3[Vehicle Scanner] Scan cancelled by %s (ID: %d)^7', 
            xPlayer.getName(), xPlayer.source))
    end
end, true, {
    help = 'Cancel the current vehicle scan',
    args = {}
})

-- Command to view last scan results
ESX.RegisterCommand('scanstatus', 'user', function(xPlayer, args, showError)
    if scanInProgress then
        local elapsedTime = os.time() - scanStartTime
        notifyPlayer(xPlayer.source, 
            'Scan in progress... (Running for ' .. formatDuration(elapsedTime) .. ')', 
            'info')
        return
    end

    if not scanResults or not next(scanResults) then
        notifyPlayer(xPlayer.source, 
            'No scans completed yet. Use /getvehicledata to start.', 
            'warning')
        return
    end

    local successCount = 0
    local errorCount = 0

    for _, data in pairs(scanResults) do
        if data.error then
            errorCount = errorCount + 1
        else
            successCount = successCount + 1
        end
    end

    local statusMessage = string.format(
        'Last scan results:\n✓ Success: %d | ✗ Errors: %d\nFile: %s',
        successCount, errorCount, Config.OutputFile
    )
    
    notifyPlayer(xPlayer.source, statusMessage, 'success')
end, true, {
    help = 'View last scan status',
    args = {}
})

-- Command to clear model cache (client-side)
ESX.RegisterCommand('clearcache', 'admin', function(xPlayer, args, showError)
    TriggerClientEvent('vehiclescanner:clearCache', xPlayer.source)
    notifyPlayer(xPlayer.source, 'Model hash cache cleared', 'success')
end, true, {
    help = 'Clear the vehicle model hash cache (admin only)',
    args = {}
})

-- Command to view scan statistics
ESX.RegisterCommand('scanstats', 'user', function(xPlayer, args, showError)
    if not scanResults or not next(scanResults) then
        notifyPlayer(xPlayer.source, 'No scan data available', 'warning')
        return
    end

    local stats = {
        total = 0,
        success = 0,
        errors = 0,
        byClass = {},
        byType = {}
    }

    for _, data in pairs(scanResults) do
        stats.total = stats.total + 1
        
        if data.error then
            stats.errors = stats.errors + 1
        else
            stats.success = stats.success + 1
            
            -- Count by class
            local className = data.vehicleClassName or 'Unknown'
            stats.byClass[className] = (stats.byClass[className] or 0) + 1
            
            -- Count by type
            local vehicleType = data.vehicleType or 'Unknown'
            stats.byType[vehicleType] = (stats.byType[vehicleType] or 0) + 1
        end
    end

    -- Build statistics message
    local statsMessage = string.format(
        'Scan Statistics:\nTotal: %d | Success: %d | Errors: %d',
        stats.total, stats.success, stats.errors
    )
    
    notifyPlayer(xPlayer.source, statsMessage, 'info')
    
    if Config.DebugMode then
        print('^2[Vehicle Scanner] Statistics:^7')
        print('^3By Class:^7')
        for class, count in pairs(stats.byClass) do
            print(string.format('  %s: %d', class, count))
        end
        print('^3By Type:^7')
        for vtype, count in pairs(stats.byType) do
            print(string.format('  %s: %d', vtype, count))
        end
    end
end, true, {
    help = 'View detailed scan statistics',
    args = {}
})

-- Startup message
CreateThread(function()
    Wait(1000)
    print('^2==================================^7')
    print('^2Vehicle Data Scanner v2.0 loaded!^7')
    print('^2Optimized with ox_lib integration^7')
    print('^2==================================^7')
    print('^3Available Commands:^7')
    print('  ^5/getvehicledata^7 - Start vehicle scan')
    print('  ^5/scanvehicles^7 - Alternative scan command')
    print('  ^5/cancelscan^7 - Cancel current scan')
    print('  ^5/scanstatus^7 - View last scan status')
    print('  ^5/scanstats^7 - View detailed statistics')
    print('  ^5/clearcache^7 - Clear model cache (admin)')
    print('^2==================================^7')
    print(string.format('^3Configured vehicles: ^2%d^7', #Config.Vehicles))
    print(string.format('^3Batch size: ^2%d^7', Config.BatchSize))
    print(string.format('^3Debug mode: ^2%s^7', Config.DebugMode and 'Enabled' or 'Disabled'))
    print('^2==================================^7')
end)
