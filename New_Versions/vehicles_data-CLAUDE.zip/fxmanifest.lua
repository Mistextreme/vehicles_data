fx_version 'cerulean'
game 'gta5'

author 'Vehicle Data Scanner'
description 'Comprehensive vehicle metadata extraction and export system for ESX - Optimized with ox_lib'
version '2.0.0'

lua54 'yes'

dependencies {
    'es_extended',
    'ox_lib'
}

shared_scripts {
    '@es_extended/imports.lua',
    '@ox_lib/init.lua',
    'config.lua'
}

client_scripts {
    'client/scanner.lua'
}

server_scripts {
    'server/main.lua'
}
