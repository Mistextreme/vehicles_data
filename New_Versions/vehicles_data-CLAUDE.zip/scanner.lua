-- Vehicle Data Scanner - Client Side (Optimized)
-- Extracts comprehensive vehicle metadata via game natives
-- Integrated with ox_lib for modern UI/UX

local scanning = false
local modelHashCache = {}

-- Modern notification system using ox_lib
local function notify(message, type)
    lib.notify({
        title = 'Vehicle Scanner',
        description = message,
        type = type or 'info',
        position = Config.NotifyPosition,
        duration = Config.NotifyDuration
    })
end

-- Get cached model hash or compute and cache it
local function getModelHash(modelName)
    if Config.CacheModelHashes and modelHashCache[modelName] then
        return modelHashCache[modelName]
    end
    
    local hash = GetHashKey(modelName)
    
    if Config.CacheModelHashes then
        modelHashCache[modelName] = hash
    end
    
    return hash
end

-- Cleanup model resources
local function cleanupModel(modelHash)
    if Config.AutoCleanup then
        SetModelAsNoLongerNeeded(modelHash)
    end
end

-- Extract all accessible vehicle data
local function extractVehicleData(modelName)
    local modelHash = getModelHash(modelName)
    
    -- Validate model
    if not IsModelAVehicleModel(modelHash) then
        return nil, 'Invalid vehicle model'
    end

    -- Request and load model
    RequestModel(modelHash)
    local timeout = 0
    while not HasModelLoaded(modelHash) and timeout < Config.ModelTimeout do
        Wait(10)
        timeout = timeout + 1
    end

    if not HasModelLoaded(modelHash) then
        cleanupModel(modelHash)
        return nil, 'Failed to load model'
    end

    -- Spawn temporary vehicle to extract data
    local coords = GetEntityCoords(PlayerPedId())
    local vehicle = CreateVehicle(modelHash, coords.x, coords.y, coords.z + 5, 0.0, true, false)

    if vehicle == 0 then
        cleanupModel(modelHash)
        return nil, 'Failed to spawn vehicle'
    end

    -- Wait for vehicle to fully spawn
    local spawnTimeout = 0
    while not DoesEntityExist(vehicle) and spawnTimeout < Config.SpawnTimeout do
        Wait(10)
        spawnTimeout = spawnTimeout + 1
    end

    if not DoesEntityExist(vehicle) then
        cleanupModel(modelHash)
        return nil, 'Vehicle despawned before data extraction'
    end

    -- Extract all available data
    local data = {
        modelName = modelName,
        modelHash = modelHash,
        displayName = GetLabelText(GetDisplayNameFromVehicleModel(modelHash)),
        
        -- Performance metrics
        maxSpeed = GetVehicleModelMaxSpeed(modelHash),
        acceleration = GetVehicleModelAcceleration(modelHash),
        braking = GetVehicleModelMaxBraking(modelHash),
        engineHealth = GetVehicleEngineHealth(vehicle),
        bodyHealth = GetVehicleBodyHealth(vehicle),
        
        -- Handling data (via natives)
        mass = GetVehicleHandlingFloat(vehicle, 'CHandlingData', 'fMass'),
        traction = GetVehicleHandlingFloat(vehicle, 'CHandlingData', 'fTractionCurveMax'),
        turnMass = GetVehicleHandlingFloat(vehicle, 'CHandlingData', 'fInertiaMultiplier'),
        dragCoefficient = GetVehicleHandlingFloat(vehicle, 'CHandlingData', 'fDragCoeff'),
        centreOfMassOffsetX = GetVehicleHandlingVector(vehicle, 'CHandlingData', 'vecCentreOfMassOffset').x,
        centreOfMassOffsetY = GetVehicleHandlingVector(vehicle, 'CHandlingData', 'vecCentreOfMassOffset').y,
        centreOfMassOffsetZ = GetVehicleHandlingVector(vehicle, 'CHandlingData', 'vecCentreOfMassOffset').z,
        
        -- Configuration
        seats = GetVehicleMaxNumberOfPassengers(vehicle),
        doors = GetNumberOfVehicleDoors(vehicle),
        
        -- Type and class
        vehicleType = GetVehicleType(vehicle),
        vehicleClass = GetVehicleClass(vehicle),
        vehicleClassName = GetVehicleClassFromName(modelHash),
        
        -- Other properties
        hasModKit = GetVehicleModKit(vehicle) ~= -1,
        isBike = IsThisModelABike(modelHash),
        isBicycle = IsThisModelABicycle(modelHash),
        isHeli = IsThisModelAHeli(modelHash),
        isPlane = IsThisModelAPlane(modelHash),
        isBoat = IsThisModelABoat(modelHash),
        isQuadbike = IsThisModelAQuadbike(modelHash),
        
        -- Additional metadata
        timestamp = os.time(),
        scanVersion = '2.0.0'
    }

    -- Get door data
    data.doorCount = 0
    data.doorData = {}
    for door = 0, 7 do
        if IsVehicleDoorFullyOpen(vehicle, door) or GetVehicleDoorAngleRatio(vehicle, door) >= 0 then
            local doorAngle = GetVehicleDoorAngleRatio(vehicle, door)
            if doorAngle > 0 or door < data.doors then
                data.doorCount = data.doorCount + 1
                table.insert(data.doorData, {
                    id = door,
                    angleRatio = doorAngle
                })
            end
        end
    end

    -- Get window data
    data.windowCount = 0
    data.windowData = {}
    for window = 0, 7 do
        if not IsVehicleWindowIntact(vehicle, window) or window < 4 then
            data.windowCount = data.windowCount + 1
            table.insert(data.windowData, {
                id = window,
                intact = IsVehicleWindowIntact(vehicle, window)
            })
        end
    end

    -- Cleanup
    DeleteEntity(vehicle)
    cleanupModel(modelHash)

    return data
end

-- Process a batch of vehicles simultaneously
local function processBatch(vehicles, startIdx, batchSize, totalVehicles)
    local batchResults = {}
    local batchEnd = math.min(startIdx + batchSize - 1, #vehicles)
    local batchPromises = {}
    
    for i = startIdx, batchEnd do
        if not scanning then break end
        
        local vehicleName = vehicles[i]
        
        -- Process vehicle asynchronously
        CreateThread(function()
            local data, err = extractVehicleData(vehicleName)
            
            if data then
                batchResults[vehicleName] = data
                TriggerServerEvent('vehiclescanner:updateProgress', vehicleName, i, totalVehicles, 'success')
            else
                batchResults[vehicleName] = { error = err, timestamp = os.time() }
                TriggerServerEvent('vehiclescanner:updateProgress', vehicleName, i, totalVehicles, 'error')
            end
        end)
    end
    
    -- Wait for batch to complete
    local checkInterval = 0
    while checkInterval < 100 do
        local completed = 0
        for i = startIdx, batchEnd do
            if batchResults[vehicles[i]] ~= nil then
                completed = completed + 1
            end
        end
        
        if completed >= (batchEnd - startIdx + 1) then
            break
        end
        
        Wait(50)
        checkInterval = checkInterval + 1
    end
    
    return batchResults
end

-- Listen for scan request from server
RegisterNetEvent('vehiclescanner:startScan', function(vehicles)
    if scanning then
        notify('Scan already in progress', 'error')
        return
    end

    -- Confirmation dialog for large scans
    if Config.UseConfirmation and #vehicles > 10 then
        local alert = lib.alertDialog({
            header = 'Vehicle Data Scanner',
            content = 'You are about to scan ' .. #vehicles .. ' vehicles. This process may take several minutes.\n\nProceed with scan?',
            centered = true,
            cancel = true,
            labels = {
                confirm = 'Start Scan',
                cancel = 'Cancel'
            }
        })

        if alert == 'cancel' then
            notify('Scan cancelled by user', 'warning')
            return
        end
    end

    scanning = true
    local results = {}
    local total = #vehicles
    local processedCount = 0
    
    notify('Starting scan of ' .. total .. ' vehicles...', 'success')

    -- Show progress bar if enabled
    local progressActive = false
    if Config.ShowProgressBar then
        progressActive = true
        CreateThread(function()
            while scanning and progressActive do
                local progress = (processedCount / total) * 100
                
                if lib.progressActive() then
                    lib.progressCancel()
                end
                
                lib.progressBar({
                    duration = Config.BatchDelay * math.ceil(total / Config.BatchSize),
                    label = 'Scanning vehicles... (' .. processedCount .. '/' .. total .. ')',
                    useWhileDead = false,
                    canCancel = true,
                    disable = {
                        car = false,
                        move = false,
                        combat = false
                    },
                    position = Config.ProgressBarPosition
                })
                
                Wait(500)
            end
        end)
    end

    -- Process vehicles in batches
    for i = 1, total, Config.BatchSize do
        if not scanning then break end

        local batchResults = processBatch(vehicles, i, Config.BatchSize, total)
        
        -- Merge batch results
        for vehicleName, data in pairs(batchResults) do
            results[vehicleName] = data
            processedCount = processedCount + 1
        end

        -- Delay between batches
        if i + Config.BatchSize <= total then
            Wait(Config.BatchDelay)
        end
    end

    progressActive = false
    scanning = false
    
    -- Clear any active progress bars
    if lib.progressActive() then
        lib.progressCancel()
    end
    
    TriggerServerEvent('vehiclescanner:scanComplete', results)
    notify('Scan completed! Processed ' .. processedCount .. ' vehicles', 'success')
end)

-- Cancel scan
RegisterNetEvent('vehiclescanner:cancelScan', function()
    if scanning then
        scanning = false
        
        if lib.progressActive() then
            lib.progressCancel()
        end
        
        notify('Vehicle scan cancelled', 'warning')
    else
        notify('No scan in progress', 'error')
    end
end)

-- Clear model hash cache (utility command)
RegisterNetEvent('vehiclescanner:clearCache', function()
    modelHashCache = {}
    notify('Model hash cache cleared', 'info')
end)

-- Debug: Show current cache size
if Config.DebugMode then
    RegisterCommand('scancache', function()
        local cacheSize = 0
        for _ in pairs(modelHashCache) do
            cacheSize = cacheSize + 1
        end
        print('^3[DEBUG] Cache size: ' .. cacheSize .. ' entries^7')
        notify('Cache contains ' .. cacheSize .. ' model hashes', 'info')
    end, false)
end
