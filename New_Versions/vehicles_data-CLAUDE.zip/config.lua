-- Vehicle Data Scanner Configuration
-- Optimized for ESX Legacy + ox_lib

Config = {
    -- List of vehicles to scan
    Vehicles = {
        'adder',
        'sultanrs',
        't20',
        'baller',
        'dominator',
        'fugitive',
        'granger',
        'hydra',
        'oracle',
        'voltic',
        'bullet',
        'cheetah',
        'entity2',
        'entityxf',
        'turismo2',
        'nero',
        'zentorno',
        'jester',
        'banshee2',
        'pfister811',
        'comet2',
    },

    -- Output file name
    OutputFile = 'vehicle_data.json',

    -- Performance settings
    BatchSize = 3, -- Number of vehicles to process simultaneously (3-5 recommended)
    BatchDelay = 50, -- ms delay between batches (reduced from 100ms)
    ModelTimeout = 100, -- Iterations to wait for model load
    SpawnTimeout = 50, -- Iterations to wait for vehicle spawn
    
    -- Notification settings (ox_lib integration)
    NotifyInterval = 500, -- ms between notifications
    NotifyPosition = 'top-right', -- ox_lib notify position: top, top-right, top-left, bottom, bottom-right, bottom-left, center-right, center-left
    NotifyDuration = 4000, -- Duration in ms for notifications
    
    -- Progress bar settings (ox_lib)
    ShowProgressBar = true, -- Enable visual progress bar during scan
    ProgressBarPosition = 'bottom', -- bottom or middle
    
    -- Advanced settings
    DebugMode = false, -- Enable detailed console logs
    UseConfirmation = true, -- Ask for confirmation before starting large scans
    AutoCleanup = true, -- Automatically cleanup unused models after scan
    CacheModelHashes = true, -- Cache model hashes to improve performance
}
